package test;

import static org.junit.Assert.*;

import org.junit.Test;

public class FormulasHandlerTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
